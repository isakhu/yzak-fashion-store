#!/usr/bin/env python3
"""
Quick setup script for the E-Commerce API
Run this to set up the project automatically
"""

import os
import sys
import subprocess
import shutil

def run_command(command, description):
    """Run a shell command and handle errors"""
    print(f"🔄 {description}...")
    try:
        result = subprocess.run(command, shell=True, check=True, capture_output=True, text=True)
        print(f"✅ {description} completed successfully!")
        return True
    except subprocess.CalledProcessError as e:
        print(f"❌ Error during {description}:")
        print(f"Command: {command}")
        print(f"Error: {e.stderr}")
        return False

def check_python():
    """Check if Python is installed and version is adequate"""
    try:
        version = sys.version_info
        if version.major == 3 and version.minor >= 8:
            print(f"✅ Python {version.major}.{version.minor}.{version.micro} is installed")
            return True
        else:
            print(f"❌ Python 3.8+ required, found {version.major}.{version.minor}.{version.micro}")
            return False
    except Exception as e:
        print(f"❌ Error checking Python version: {e}")
        return False

def setup_project():
    """Main setup function"""
    print("🚀 Setting up E-Commerce API Project")
    print("=" * 50)
    
    # Check Python version
    if not check_python():
        print("\n📥 Please install Python 3.8+ from https://python.org/downloads/")
        return False
    
    # Create virtual environment
    if not os.path.exists("venv"):
        if not run_command("python -m venv venv", "Creating virtual environment"):
            return False
    else:
        print("✅ Virtual environment already exists")
    
    # Determine activation command based on OS
    if os.name == 'nt':  # Windows
        activate_cmd = "venv\\Scripts\\activate"
        pip_cmd = "venv\\Scripts\\pip"
        python_cmd = "venv\\Scripts\\python"
    else:  # Mac/Linux
        activate_cmd = "source venv/bin/activate"
        pip_cmd = "venv/bin/pip"
        python_cmd = "venv/bin/python"
    
    # Install dependencies
    if not run_command(f"{pip_cmd} install -r requirements.txt", "Installing Python packages"):
        return False
    
    # Create .env file if it doesn't exist
    if not os.path.exists(".env"):
        if os.path.exists(".env.example"):
            shutil.copy(".env.example", ".env")
            print("✅ Created .env file from template")
        else:
            print("⚠️  .env.example not found, you may need to create .env manually")
    else:
        print("✅ .env file already exists")
    
    print("\n🎉 Setup completed successfully!")
    print("\n📋 Next steps:")
    print("1. Activate virtual environment:")
    if os.name == 'nt':
        print("   venv\\Scripts\\activate")
    else:
        print("   source venv/bin/activate")
    
    print("2. Start the development server:")
    print("   python -m app.main")
    print("   OR")
    print("   uvicorn app.main:app --reload")
    
    print("\n🌐 Once running, visit:")
    print("   • API Docs: http://localhost:8000/docs")
    print("   • Health Check: http://localhost:8000/health")
    
    print("\n🔑 Default admin credentials:")
    print("   • Username: admin")
    print("   • Password: admin123")
    
    return True

if __name__ == "__main__":
    try:
        setup_project()
    except KeyboardInterrupt:
        print("\n\n⚠️  Setup interrupted by user")
    except Exception as e:
        print(f"\n❌ Unexpected error during setup: {e}")
        print("Please check the README.md for manual setup instructions")