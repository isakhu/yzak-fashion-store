# 🚀 Quick Start Guide

## What You Need to Download

### 1. Python (Required)
- **Download**: https://python.org/downloads/
- **Version**: Python 3.8 or higher
- **Important**: During installation, check "Add Python to PATH"

### 2. Code Editor (Recommended)
- **VS Code**: https://code.visualstudio.com/ (Free, most popular)
- **PyCharm**: https://jetbrains.com/pycharm/ (Professional IDE)
- **Any text editor works too**

## 🏃‍♂️ Super Quick Setup (3 Steps)

### Option A: Automatic Setup (Easiest)
```bash
# 1. Open terminal/command prompt in project folder
# 2. Run the setup script
python setup.py

# 3. Start the server
python -m app.main
```

### Option B: Manual Setup
```bash
# 1. Create virtual environment
python -m venv venv

# 2. Activate it (Windows)
venv\Scripts\activate
# Or on Mac/Linux:
source venv/bin/activate

# 3. Install packages
pip install -r requirements.txt

# 4. Copy environment file
copy .env.example .env

# 5. Start server
python -m app.main
```

### Option C: Windows Users (Super Easy)
1. Double-click `run.bat` file
2. That's it! 🎉

## 🎯 Test Your API

1. **Open your browser**: http://localhost:8000/docs
2. **Login as admin**:
   - Click "Authorize" 
   - Username: `admin`
   - Password: `admin123`
3. **Try creating a product category**
4. **Create some products**
5. **Register a new user**
6. **Create an order**

## 📱 What Each File Does

- **`app/main.py`**: The main application (like the engine)
- **`app/models/`**: Database tables (users, products, orders)
- **`app/routers/`**: API endpoints (the URLs people can call)
- **`requirements.txt`**: List of Python packages needed
- **`.env`**: Configuration settings (like database location)

## 🔧 Common Issues & Solutions

### "Python not found"
- Install Python from python.org
- Make sure "Add to PATH" was checked during installation
- Restart your terminal/command prompt

### "pip not found"
- Usually comes with Python
- Try: `python -m pip --version`

### "Permission denied"
- On Windows: Run as Administrator
- On Mac/Linux: Use `sudo` if needed

### "Port already in use"
- Something else is using port 8000
- Change port: `uvicorn app.main:app --port 8001`

## 🎓 Learning Path

1. **Start here**: Look at `app/main.py` - this is the entry point
2. **Understand models**: Check `app/models/user.py` - see how data is structured
3. **Follow a request**: Look at `app/routers/auth.py` - see how login works
4. **Try the API**: Use the Swagger docs at http://localhost:8000/docs

## 💡 Impress Your Interviewers

This project shows you understand:
- **REST API design** (GET, POST, PUT, DELETE)
- **Database relationships** (users have orders, orders have items)
- **Authentication & Security** (JWT tokens, password hashing)
- **Modern Python** (FastAPI, Pydantic, SQLAlchemy)
- **Code organization** (clean folder structure)
- **API documentation** (auto-generated docs)

## 🚀 Next Steps

Once you have it running:
1. **Explore the code** - understand how each part works
2. **Add features** - maybe a shopping cart or product reviews
3. **Deploy it** - put it online with Heroku or Railway
4. **Add tests** - write unit tests to show best practices

Good luck with your internship! 🍀