#!/usr/bin/env python3
"""
Test login functionality
"""
import requests
import json

def test_login():
    """Test the login endpoint"""
    
    # First, let's try to register a user
    print("🔄 Testing user registration...")
    register_data = {
        "username": "testuser",
        "email": "test@example.com",
        "full_name": "Test User",
        "password": "test123"
    }
    
    try:
        response = requests.post("http://localhost:8000/auth/register", json=register_data)
        if response.status_code == 200:
            print("✅ User registration successful!")
        else:
            print(f"⚠️ Registration response: {response.status_code} - {response.text}")
    except Exception as e:
        print(f"❌ Registration error: {e}")
    
    # Now test login with the registered user
    print("\n🔄 Testing login...")
    login_data = {
        "username": "testuser",
        "password": "test123",
        "grant_type": "password"
    }
    
    try:
        response = requests.post(
            "http://localhost:8000/auth/login",
            data=login_data,  # Use data instead of json for form data
            headers={"Content-Type": "application/x-www-form-urlencoded"}
        )
        
        if response.status_code == 200:
            result = response.json()
            print("✅ Login successful!")
            print(f"Token: {result.get('access_token', 'No token')[:50]}...")
        else:
            print(f"❌ Login failed: {response.status_code}")
            print(f"Response: {response.text}")
            
    except Exception as e:
        print(f"❌ Login error: {e}")

    # Test admin login
    print("\n🔄 Testing admin login...")
    admin_login_data = {
        "username": "admin",
        "password": "admin",
        "grant_type": "password"
    }
    
    try:
        response = requests.post(
            "http://localhost:8000/auth/login",
            data=admin_login_data,
            headers={"Content-Type": "application/x-www-form-urlencoded"}
        )
        
        if response.status_code == 200:
            result = response.json()
            print("✅ Admin login successful!")
            print(f"Token: {result.get('access_token', 'No token')[:50]}...")
        else:
            print(f"❌ Admin login failed: {response.status_code}")
            print(f"Response: {response.text}")
            
    except Exception as e:
        print(f"❌ Admin login error: {e}")

if __name__ == "__main__":
    test_login()